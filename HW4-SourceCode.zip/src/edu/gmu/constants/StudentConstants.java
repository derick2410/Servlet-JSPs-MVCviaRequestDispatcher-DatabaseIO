/**
 * 
 */
package edu.gmu.constants;

/**
 * 
 * 
 * @author Derick Augustine Coutinho
 * @since 12 November 2014
 * @version 0.1
 */
public class StudentConstants {

}