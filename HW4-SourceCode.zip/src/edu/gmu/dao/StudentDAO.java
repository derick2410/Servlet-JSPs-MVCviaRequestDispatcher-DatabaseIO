/**
 * 
 */
package edu.gmu.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.apache.commons.lang3.StringUtils;

import edu.gmu.bean.StudentBean;

/**
 * 
 * 
 * @author Derick Augustine Coutinho
 * @version 0.1
 * @since 2nd Nov 2014
 */
public class StudentDAO {
	final private String DRIVER_NAME = "oracle.jdbc.driver.OracleDriver";
	final private String DATABASE_URL = "jdbc:oracle:thin:@apollo.ite.gmu.edu:1521:ite10g";
	final private String USER_NAME = "dcoutinh";
	final private String PASSWORD = "JesuMary25";

	public Connection getConnection() throws Exception {
		Class.forName(DRIVER_NAME);
		Connection conn = DriverManager.getConnection(DATABASE_URL, USER_NAME,
				PASSWORD);
		return conn;
	}

	public boolean saveStudentSurveyInfo(StudentBean studentBean) {
		boolean isUniqueConstraintViolated = false;

		PreparedStatement preparedStatement = null;
		Connection sqlConnection = null;
		try {
			sqlConnection = getConnection();

			preparedStatement = sqlConnection
					.prepareStatement("insert into studentinfo (studentid, name, address, zipcode, city, state, telnum, email, gradmonth, gradyear, "
							+ "url, surveydate, recomend, interest, likings) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

			preparedStatement.setString(1, studentBean.getStudentId());
			preparedStatement.setString(2, studentBean.getStudentName());
			preparedStatement.setString(3, studentBean.getStreetAddr());
			preparedStatement.setInt(4,
					Integer.parseInt(studentBean.getZipCode()));
			preparedStatement.setString(5, studentBean.getCityDiv());
			preparedStatement.setString(6, studentBean.getStateDiv());
			preparedStatement.setString(7, studentBean.getTelNum());
			preparedStatement.setString(8, studentBean.getEmailAddr());
			preparedStatement.setString(9, studentBean.getGradMonth());

			if (StringUtils.isEmpty(studentBean.getGradYear())) {
				studentBean.setGradYear("0");
			}
			preparedStatement.setInt(10,
					Integer.parseInt(studentBean.getGradYear()));
			preparedStatement.setString(11, studentBean.getUrl());
			preparedStatement.setString(12, studentBean.getDateOfSurvey());
			preparedStatement.setString(13, studentBean.getRecommendation());
			preparedStatement.setString(14, studentBean.getInterest());
			preparedStatement.setString(15, studentBean.getLikings());

			preparedStatement.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();

			if (StringUtils.contains(e.getMessage(), "unique constraint")) {
				isUniqueConstraintViolated = true;
			}
		} finally {
			try {
				preparedStatement.close();
				sqlConnection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return isUniqueConstraintViolated;
	}

	public ArrayList<String> retrieveStudentIds() {
		ArrayList<String> studentIds = null;

		ResultSet resultSet = null;
		PreparedStatement preparedStatement = null;
		Connection sqlConnection = null;
		try {
			studentIds = new ArrayList<String>();
			sqlConnection = getConnection();

			String query = "SELECT studentid FROM studentinfo";
			preparedStatement = sqlConnection.prepareStatement(query);

			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				studentIds.add(resultSet.getString("studentid"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				resultSet.close();
				preparedStatement.close();
				sqlConnection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return studentIds;
	}

	public StudentBean retrieveStudentSurveyInfo(String studentId) {
		StudentBean studentBean = null;

		ResultSet resultSet = null;
		PreparedStatement preparedStatement = null;
		Connection sqlConnection = null;
		try {
			studentBean = new StudentBean();
			sqlConnection = getConnection();

			String query = "SELECT * FROM studentinfo WHERE studentid = '"
					+ studentId + "'";
			preparedStatement = sqlConnection.prepareStatement(query);

			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				studentBean.setStudentId(studentId);
				studentBean.setStudentName(resultSet.getString(2));
				studentBean.setStreetAddr(resultSet.getString(3));
				studentBean.setZipCode(resultSet.getString(4));
				studentBean.setCityDiv(resultSet.getString(5));
				studentBean.setStateDiv(resultSet.getString(6));
				studentBean.setTelNum(resultSet.getString(7));
				studentBean.setEmailAddr(resultSet.getString(8));
				studentBean.setGradMonth(resultSet.getString(9));
				studentBean.setGradYear(resultSet.getString(10));
				studentBean.setUrl(resultSet.getString(11));
				studentBean.setDateOfSurvey(resultSet.getString(12));
				studentBean.setRecommendation(resultSet.getString(13));
				studentBean.setInterest(resultSet.getString(14));
				studentBean.setLikings(resultSet.getString(15));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				resultSet.close();
				preparedStatement.close();
				sqlConnection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return studentBean;
	}
}