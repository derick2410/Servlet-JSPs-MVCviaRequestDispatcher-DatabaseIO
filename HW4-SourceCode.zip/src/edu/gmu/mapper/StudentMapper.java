/**
 * 
 */
package edu.gmu.mapper;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;

import edu.gmu.bean.StudentBean;

/**
 * This class is used for mapping all the values from the student form (in the
 * request) to the student and data bean.
 * 
 * @author Derick Augustine Coutinho
 * @version 0.1
 * @since 16 November 2014
 *
 */
public class StudentMapper {

	public StudentBean setStudentSurveyDetails(HttpServletRequest request) {
		StudentBean studentBean = new StudentBean();

		studentBean.setStudentId(request.getParameter("studentId"));

		StringBuilder nameBuilder = new StringBuilder();
		nameBuilder.append(request.getParameter("firstName"));
		nameBuilder.append(" ");
		nameBuilder.append(request.getParameter("middleName"));
		nameBuilder.append(" ");
		nameBuilder.append(request.getParameter("lastName"));

		studentBean.setStudentName(nameBuilder.toString().toUpperCase());

		studentBean.setStreetAddr(request.getParameter("streetAddr"));
		studentBean.setZipCode(request.getParameter("zipCode"));
		studentBean.setCityDiv(request.getParameter("cityDiv"));
		studentBean.setStateDiv(request.getParameter("stateDiv"));
		studentBean.setTelNum(request.getParameter("telNum"));
		studentBean.setEmailAddr(request.getParameter("emailAddr"));
		studentBean.setGradMonth(request.getParameter("gradMonth"));
		studentBean.setGradYear(request.getParameter("gradYear"));
		studentBean.setUrl(request.getParameter("url"));
		studentBean.setDateOfSurvey(request.getParameter("dateOfSurvey"));
		studentBean.setRecommendation(request.getParameter("recommend"));
		studentBean.setInterest(request.getParameter("interest"));

		String[] likingsValues = request.getParameterValues("likings");
		String like = StringUtils.EMPTY;
		for (int i = 0; i < likingsValues.length; i++) {
			like = like + likingsValues[i] + " ";
		}
		studentBean.setLikings(like);

		return studentBean;
	}
}