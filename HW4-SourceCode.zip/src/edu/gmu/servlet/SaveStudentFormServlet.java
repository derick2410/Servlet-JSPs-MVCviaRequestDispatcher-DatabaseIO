package edu.gmu.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;

import edu.gmu.bean.DataBean;
import edu.gmu.bean.StudentBean;
import edu.gmu.dao.StudentDAO;
import edu.gmu.mapper.StudentMapper;
import edu.gmu.processor.DataProcessor;

/**
 * Servlet implementation class SaveStudentFormServlet. Servlet class is used to
 * save the student information which is retrieved from the form and to perform
 * some calculations.
 * 
 * @author Derick Augustine Coutinho
 * @version 0.1
 * @since 11 November 2014
 */
@WebServlet(description = "", urlPatterns = { "/saveSurveyFormData" })
public class SaveStudentFormServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public SaveStudentFormServlet() {
		super();
	}

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {

	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {

	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		StudentDAO studentDAO = new StudentDAO();
		StudentBean studentBean = studentDAO.retrieveStudentSurveyInfo(request
				.getParameter("studentId"));

		HttpSession ses = request.getSession();
		ses.setAttribute("studentBean", studentBean);

		String fwdToJsp = StringUtils.EMPTY;

		if (null != studentBean) {
			fwdToJsp = "/jsps/studentJSP.jsp";
		} else {
			fwdToJsp = "/jsps/noSuchStudentJSP.jsp";
		}

		RequestDispatcher reqDispatcher = request
				.getRequestDispatcher(fwdToJsp);
		reqDispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		HttpSession httpSession = request.getSession();

		// Map current students survey details.
		StudentMapper studentMapper = new StudentMapper();
		StudentBean studentBean = studentMapper
				.setStudentSurveyDetails(request);

		StudentDAO studentDAO = new StudentDAO();
		// Save current student survey details.
		studentDAO.saveStudentSurveyInfo(studentBean);

		// Retrieve all the student ID's and set it into the session.
		httpSession.setAttribute("studentIdsList",
				studentDAO.retrieveStudentIds());

		// Calculate Mean and Standard Deviation of the numbers.
		DataProcessor dataProcessor = new DataProcessor();
		DataBean dataBean = dataProcessor
				.calculateMeanStandardDeviation(request
						.getParameter("dataField"));

		httpSession.setAttribute("dataBean", dataBean);
		httpSession.setAttribute("dataNumbers",
				request.getParameter("dataField"));

		String fwdToJsp = StringUtils.EMPTY;

		if (null != dataBean && dataBean.getMeanValue() > 90) {
			// WinnerAcknowledgement JSP
			fwdToJsp = "/jsps/winnerAcknowledgement.jsp";
		} else {
			// SimpleAcknowledgement JSP
			fwdToJsp = "/jsps/simpleAcknowledgement.jsp";
		}

		if (StringUtils.isEmpty((String) httpSession
				.getAttribute("dataNumbers"))) {
			httpSession.setAttribute("noDataNumbersEntered", "true");
		}

		RequestDispatcher reqDispatcher = request
				.getRequestDispatcher(fwdToJsp);
		reqDispatcher.forward(request, response);
	}
}